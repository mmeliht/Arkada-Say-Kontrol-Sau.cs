/*************************************************************************************************************************
 **
 **                                             	SAKARYA �N�VERS�TES�
 **                                        B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
 **                                            B�LG�SAYAR M�HEND�SL��� B�L�M�
 **                                           NESNEYE DAYALI PROGRAMLAMA DERS�
 **	                                             2019-2020 BAHAR D�NEM�
 **    
 **
 **
 **
 **                                            �DEV NUMARASI..........: 2
 **                                            ��RENC� ADI............: Mustafa Melih T�FEKC�O�LU
 **                                            ��RENC� NUMARASI.......: B191210004
 **                                            DERS�N ALINDI�I GRUP...: 1.��retim B grubu
 **
 **
 **
 ***************************************************************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B191210004
{
    static class Program
    {
        
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
